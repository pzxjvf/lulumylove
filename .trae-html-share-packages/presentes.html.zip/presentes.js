(() => {
  "use strict";

  const STORE = "cantinho_presentes_v1";
  const FIRST_GIFT = {
    id: "buque-lirios-lulu",
    name: "O buquê de lírios brancos",
    category: "flowers",
    note: "Lírios brancos, mosquitinho, folhagens, papel amarelo e uma caixinha dourada de Ferrero Rocher. Um presente cheio de carinho. 💛",
    date: ""
  };
  const CATEGORIES = {
    flowers: { label: "Flores", icon: "💐" },
    pet: { label: "Bichinho", icon: "🐾" },
    jewel: { label: "Joia ou acessório", icon: "💎" },
    date: { label: "Passeio ou encontro", icon: "🎟️" },
    other: { label: "Outro mimo", icon: "🎁" }
  };
  const $ = (selector) => document.querySelector(selector);
  const list = $("#giftList");
  const message = $("#sceneMessage");
  const deleteButton = $("#deleteGift");
  let gifts = loadGifts();
  let selectedId = FIRST_GIFT.id;
  let toastTimer;

  function loadGifts() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORE));
      if (Array.isArray(saved)) return [FIRST_GIFT, ...saved.filter((item) => item && item.id !== FIRST_GIFT.id)];
    } catch (error) { /* Rebuild the collection if browser storage is unavailable. */ }
    return [FIRST_GIFT];
  }

  function saveGifts() {
    try {
      localStorage.setItem(STORE, JSON.stringify(gifts.filter((gift) => gift.id !== FIRST_GIFT.id)));
      return true;
    } catch (error) {
      showToast("Não consegui salvar neste navegador. Tente remover algumas lembranças.");
      return false;
    }
  }

  function showToast(text) {
    const el = $("#toast");
    el.textContent = text;
    el.classList.add("on");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("on"), 2700);
  }

  function safe(text) {
    return String(text || "").replace(/[&<>"']/g, (char) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[char]);
  }

  function renderList() {
    list.innerHTML = gifts.map((gift) => {
      const category = CATEGORIES[gift.category] || CATEGORIES.other;
      const isModel = gift.id === FIRST_GIFT.id;
      const details = gift.date || (isModel ? "Modelo 3D interativo" : category.label);
      return '<button class="gift-entry' + (gift.id === selectedId ? " selected" : "") +
        '" type="button" data-gift="' + safe(gift.id) + '" aria-pressed="' + (gift.id === selectedId) + '">' +
        '<span class="gift-icon">' + (isModel ? "💐" : category.icon) + "</span>" +
        '<span><span class="gift-name">' + safe(gift.name) + "</span><span class=\"gift-meta\">" + safe(details) + "</span></span>" +
        '<span class="arrow" aria-hidden="true">›</span></button>';
    }).join("");

    list.querySelectorAll("[data-gift]").forEach((button) => {
      button.addEventListener("click", () => selectGift(button.dataset.gift));
    });
    const selected = gifts.find((gift) => gift.id === selectedId);
    deleteButton.classList.toggle("on", !!selected && selected.id !== FIRST_GIFT.id);
  }

  function selectGift(id) {
    const gift = gifts.find((item) => item.id === id);
    if (!gift) return;
    selectedId = id;
    const isModel = id === FIRST_GIFT.id;
    message.classList.toggle("on", !isModel);
    if (!isModel) {
      const category = CATEGORIES[gift.category] || CATEGORIES.other;
      message.innerHTML = "<div><span style=\"font-size:2.6rem\">" + category.icon +
        "</span><strong>" + safe(gift.name) + "</strong><p>" + safe(gift.note || "Uma lembrança guardada com carinho.") +
        "</p><p style=\"margin-top:12px;font-size:.8rem\">O buquê continua aqui em 3D. Cada presente novo pode ganhar seu próprio modelo especial. 💜</p></div>";
    }
    deleteButton.classList.toggle("on", !isModel);
    renderList();
  }

  $("#giftForm").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const name = $("#giftName").value.trim();
    if (!name) return;
    const category = $("#giftCategory").value;
    const note = $("#giftNote").value.trim();
    const id = "gift-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7);
    const date = new Intl.DateTimeFormat("pt-BR", { day: "numeric", month: "short", year: "numeric" }).format(new Date());
    gifts.push({ id, name, category, note, date });
    if (!saveGifts()) { gifts.pop(); return; }
    form.reset();
    $("#formNote").textContent = "Guardado com carinho. 💌";
    selectedId = id;
    selectGift(id);
    showToast("💝 Presente guardado na coleção!");
    setTimeout(() => { $("#formNote").textContent = ""; }, 3000);
  });

  deleteButton.addEventListener("click", () => {
    const gift = gifts.find((item) => item.id === selectedId);
    if (!gift || gift.id === FIRST_GIFT.id) return;
    if (!window.confirm('Remover "' + gift.name + '" da coleção?')) return;
    gifts = gifts.filter((item) => item.id !== selectedId);
    saveGifts();
    selectedId = FIRST_GIFT.id;
    selectGift(selectedId);
    showToast("Lembrança removida.");
  });

  renderList();

  const stage = $("#stage");
  const canvas = $("#bouquetCanvas");
  const smellButton = $("#smellButton");
  const waterButton = $("#waterButton");
  let scene;
  let renderer;
  let camera;
  let bouquet;
  let petals = [];
  let wateringCan;
  let waterDrops = [];
  let waterStart = -1;
  let smellStart = -1;
  let lastFrame = performance.now();
  let dragging = false;
  let previousPointer = null;
  let autoRotate = false;
  let lastDrag = 0;
  let zoomDistance = 9.4;
  const pointers = new Map();

  const rand = (() => {
    let seed = 93217;
    return () => {
      seed = (seed * 16807) % 2147483647;
      return (seed - 1) / 2147483646;
    };
  })();

  function lineBetween(parent, a, b, radius, material, segments = 7) {
    const direction = new THREE.Vector3().subVectors(b, a);
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.82, radius, direction.length(), segments), material);
    mesh.position.copy(a).add(b).multiplyScalar(0.5);
    mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.normalize());
    parent.add(mesh);
    return mesh;
  }

  function petalGeometry(length, width, greenBase = false) {
    const rows = 19, columns = 9, positions = [], colors = [], indices = [];
    const white = new THREE.Color(greenBase ? "#557f3d" : "#dedbd3");
    const base = new THREE.Color(greenBase ? "#205a34" : "#91a048");
    const ridge = new THREE.Color(greenBase ? "#91ad56" : "#fffaf0");
    for (let row = 0; row <= rows; row++) {
      const t = row / rows;
      const taper = Math.pow(Math.sin(Math.PI * Math.pow(t, 0.78)), 0.72) * (0.82 + 0.18 * t);
      const centerColor = greenBase ? base.clone().lerp(white, Math.min(1, t * 1.7)) : base.clone().lerp(white, Math.min(1, t * 2.5));
      for (let col = 0; col <= columns; col++) {
        const u = col / columns * 2 - 1;
        const x = u * width * taper;
        const y = t * length;
        const z = -0.1 * Math.sin(Math.PI * t) * (1 - u * u) +
          0.018 * Math.sin(t * 8) * Math.pow(Math.abs(u), 5) + 0.025 * t + 0.035 * u * u;
        positions.push(x, y, z);
        const color = centerColor.clone().lerp(ridge, Math.max(0, 1 - Math.abs(u) * 3) * 0.24);
        colors.push(color.r, color.g, color.b);
      }
    }
    for (let row = 0; row < rows; row++) for (let col = 0; col < columns; col++) {
      const a = row * (columns + 1) + col, b = a + columns + 1;
      indices.push(a, b, a + 1, b, b + 1, a + 1);
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
    geometry.setIndex(indices);
    geometry.computeVertexNormals();
    return geometry;
  }

  function makePetalMaterial() {
    return new THREE.MeshStandardMaterial({
      vertexColors: true, side: THREE.DoubleSide, roughness: 0.48,
      metalness: 0, transparent: false
    });
  }

  function addLily(parent, x, y, z, size, direction = 0, tilt = 0.62) {
    const bloom = new THREE.Group();
    bloom.position.set(x, y, z);
    bloom.rotation.x = tilt;
    bloom.rotation.y = direction;
    parent.add(bloom);

    const petalGeo = petalGeometry(1.03 * size, 0.38 * size);
    const petalMat = makePetalMaterial();
    for (let i = 0; i < 6; i++) {
      const angle = i * Math.PI / 3;
      const radial = new THREE.Group();
      radial.rotation.y = angle + Math.PI;
      bloom.add(radial);
      const petal = new THREE.Mesh(petalGeo, petalMat);
      petal.rotation.x = -Math.PI / 2 + (i % 2 ? 0.12 : -0.08);
      petal.castShadow = true;
      radial.add(petal);
    }

    const green = new THREE.MeshStandardMaterial({ color: "#74a33e", roughness: 0.62 });
    const paleGreen = new THREE.MeshStandardMaterial({ color: "#a9bb45", roughness: 0.52 });
    const filament = new THREE.MeshStandardMaterial({ color: "#9eb638", roughness: 0.52 });
    const pollen = new THREE.MeshStandardMaterial({ color: "#c57c28", roughness: 0.6 });
    for (let i = 0; i < 5; i++) {
      const angle = i * Math.PI * 2 / 5 + 0.22;
      const start = new THREE.Vector3(Math.cos(angle) * 0.035, Math.sin(angle) * 0.035, 0.05 * size);
      const end = new THREE.Vector3(Math.cos(angle) * 0.15 * size, Math.sin(angle) * 0.15 * size + 0.06, 0.39 * size);
      lineBetween(bloom, start, end, 0.012 * size, filament, 5);
      const anther = new THREE.Mesh(new THREE.SphereGeometry(0.046 * size, 8, 6), pollen);
      anther.position.copy(end);
      anther.scale.set(1.7, 0.58, 0.8);
      bloom.add(anther);
    }
    const pistil = new THREE.Mesh(new THREE.SphereGeometry(0.055 * size, 10, 8), paleGreen);
    pistil.position.set(0, 0.04 * size, 0.27 * size);
    pistil.scale.set(0.78, 0.78, 1.9);
    bloom.add(pistil);

    const calyx = new THREE.Mesh(petalGeometry(0.5 * size, 0.12 * size, true), makePetalMaterial());
    for (let i = 0; i < 4; i++) {
      const leaf = calyx.clone();
      leaf.position.z = -0.06 * size;
      leaf.rotation.z = i * Math.PI / 2;
      bloom.add(leaf);
    }
    petals.push(bloom);
    return bloom;
  }

  function addLeaf(parent, x, y, z, angle, length, width) {
    const leaf = new THREE.Mesh(petalGeometry(length, width, true), makePetalMaterial());
    leaf.position.set(x, y, z);
    leaf.quaternion.setFromUnitVectors(
      new THREE.Vector3(0, 1, 0),
      new THREE.Vector3(Math.cos(angle) * 0.75, 0.62, Math.sin(angle) * 0.75).normalize()
    );
    leaf.rotation.z += 0.12 * Math.sin(angle);
    parent.add(leaf);
  }

  function makeWrapPanel(parent, angle, shade) {
    const points = [];
    const bottomY = -0.48, topY = 1.36;
    const bottomRadius = 0.39, topRadius = 1.48;
    const half = Math.PI / 12 * 0.98;
    const corners = [
      [bottomRadius, bottomY, angle - half],
      [bottomRadius, bottomY, angle + half],
      [topRadius, topY, angle + half],
      [topRadius, topY, angle - half]
    ];
    corners.forEach(([radius, y, a]) => points.push(radius * Math.cos(a), y, radius * Math.sin(a)));
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.Float32BufferAttribute(points, 3));
    geometry.setIndex([0, 1, 2, 0, 2, 3]);
    geometry.computeVertexNormals();
    const material = new THREE.MeshStandardMaterial({
      color: shade, side: THREE.DoubleSide, roughness: 0.7, metalness: 0.015
    });
    const panel = new THREE.Mesh(geometry, material);
    panel.castShadow = true;
    panel.receiveShadow = true;
    parent.add(panel);
  }

  function ferreroTexture() {
    const canvas = document.createElement("canvas");
    canvas.width = 512; canvas.height = 640;
    const c = canvas.getContext("2d");
    const gold = c.createLinearGradient(0, 0, 512, 640);
    gold.addColorStop(0, "#fff0bc"); gold.addColorStop(0.5, "#c28a36"); gold.addColorStop(1, "#fff1c8");
    c.fillStyle = gold; c.fillRect(0, 0, 512, 640);
    c.fillStyle = "#d6b45b";
    for (let y = 0; y < 640; y += 22) for (let x = 0; x < 512; x += 22) {
      c.globalAlpha = ((x + y) / 22) % 2 ? 0.18 : 0.08;
      c.fillRect(x, y, 11, 11);
    }
    c.globalAlpha = 1;
    c.fillStyle = "#fffdf2"; c.beginPath(); c.ellipse(256, 350, 160, 210, 0, 0, Math.PI * 2); c.fill();
    c.strokeStyle = "#9a7633"; c.lineWidth = 7; c.beginPath(); c.ellipse(256, 350, 153, 202, 0, 0, Math.PI * 2); c.stroke();
    c.fillStyle = "#8c6424"; c.font = "bold 52px Georgia"; c.textAlign = "center"; c.fillText("FERRERO", 256, 333);
    c.font = "bold 62px Georgia"; c.fillText("ROCHER", 256, 383);
    c.fillStyle = "#b78a39";
    for (let i = 0; i < 3; i++) { c.beginPath(); c.arc(231 + i * 24, 270 - Math.abs(1 - i) * 12, 12, 0, 7); c.fill(); }
    c.fillStyle = "#6b5128"; c.font = "bold 16px Arial"; c.fillText("SPECIAL MOMENTS", 256, 472);
    const texture = new THREE.CanvasTexture(canvas);
    texture.anisotropy = 4;
    return texture;
  }

  function addFerreroBox(parent) {
    const box = new THREE.Group();
    box.position.set(-1.55, 2.02, 0.38);
    box.rotation.y = 0.12;
    box.rotation.x = -0.08;
    parent.add(box);
    const body = new THREE.Mesh(
      new THREE.BoxGeometry(1.14, 1.38, 0.18),
      new THREE.MeshStandardMaterial({ color: "#c3994f", roughness: 0.44, metalness: 0.18 })
    );
    body.castShadow = true; body.receiveShadow = true; box.add(body);
    const label = new THREE.Mesh(
      new THREE.PlaneGeometry(1.08, 1.32),
      new THREE.MeshBasicMaterial({ map: ferreroTexture(), side: THREE.DoubleSide })
    );
    label.position.z = 0.108;
    box.add(label);
    const edge = new THREE.Mesh(
      new THREE.BoxGeometry(1.06, 1.29, 0.035),
      new THREE.MeshStandardMaterial({ color: "#e2c378", roughness: 0.38, metalness: 0.28 })
    );
    edge.position.z = -0.1;
    box.add(edge);
  }

  function addBabyBreath(parent) {
    const twig = new THREE.MeshStandardMaterial({ color: "#6c9446", roughness: 0.78 });
    const white = new THREE.MeshStandardMaterial({ color: "#fffdf8", roughness: 0.52 });
    const center = new THREE.MeshStandardMaterial({ color: "#e8ce85", roughness: 0.65 });
    const blossomPoints = [], centerPoints = [];
    for (let branch = 0; branch < 11; branch++) {
      const angle = branch * 2.399;
      const start = new THREE.Vector3(Math.cos(angle) * 0.22, 0.96, Math.sin(angle) * 0.22);
      const end = new THREE.Vector3(Math.cos(angle) * (0.95 + rand() * 0.34), 2.75 + rand() * 0.62, Math.sin(angle) * (0.95 + rand() * 0.34));
      const middle = start.clone().lerp(end, 0.53);
      middle.y += 0.13;
      lineBetween(parent, start, middle, 0.014, twig, 5);
      lineBetween(parent, middle, end, 0.011, twig, 5);
      for (let stem = 0; stem < 3; stem++) {
        const t = 0.48 + stem * 0.21;
        const origin = start.clone().lerp(end, t);
        const sideAngle = angle + (stem - 1) * 0.75;
        const bloomAt = origin.clone().add(new THREE.Vector3(Math.cos(sideAngle) * 0.26, 0.21 + rand() * 0.13, Math.sin(sideAngle) * 0.26));
        lineBetween(parent, origin, bloomAt, 0.0085, twig, 4);
        for (let floret = 0; floret < 5; floret++) {
          const a = floret * Math.PI * 0.4;
          blossomPoints.push(bloomAt.x + Math.cos(a) * 0.04, bloomAt.y + Math.sin(a) * 0.035, bloomAt.z + Math.sin(a) * 0.04);
        }
        centerPoints.push(bloomAt.x, bloomAt.y, bloomAt.z);
      }
      const tip = end.clone().add(new THREE.Vector3(0, 0.06, 0));
      for (let floret = 0; floret < 5; floret++) {
        const a = floret * Math.PI * 0.4;
        blossomPoints.push(tip.x + Math.cos(a) * 0.04, tip.y + Math.sin(a) * 0.035, tip.z + Math.sin(a) * 0.04);
      }
      centerPoints.push(tip.x, tip.y, tip.z);
    }
    function instancedSpheres(points, geometry, material, scale) {
      const count = points.length / 3, mesh = new THREE.InstancedMesh(geometry, material, count);
      const matrix = new THREE.Matrix4(), position = new THREE.Vector3(), quaternion = new THREE.Quaternion();
      const size = new THREE.Vector3(scale, scale, scale);
      for (let i = 0; i < count; i++) {
        position.set(points[i * 3], points[i * 3 + 1], points[i * 3 + 2]);
        matrix.compose(position, quaternion, size);
        mesh.setMatrixAt(i, matrix);
      }
      mesh.instanceMatrix.needsUpdate = true;
      parent.add(mesh);
    }
    const sphere = new THREE.SphereGeometry(0.05, 7, 5);
    instancedSpheres(blossomPoints, sphere, white, 0.7);
    instancedSpheres(centerPoints, sphere, center, 0.42);
  }

  function makeWateringCan() {
    const group = new THREE.Group();
    const tin = new THREE.MeshStandardMaterial({ color: "#7db5c8", roughness: 0.4, metalness: 0.24 });
    const dark = new THREE.MeshStandardMaterial({ color: "#508eaa", roughness: 0.48, metalness: 0.18 });
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.25, 0.38, 12), tin);
    body.scale.z = 0.8; group.add(body);
    const handle = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.035, 7, 15, Math.PI * 1.55), dark);
    handle.position.set(0, 0.1, -0.14); handle.rotation.z = -0.75; group.add(handle);
    const spoutStart = new THREE.Vector3(0.12, 0.05, 0.09);
    const spoutEnd = new THREE.Vector3(0.34, 0.19, 0.38);
    lineBetween(group, spoutStart, spoutEnd, 0.065, tin, 10);
    const rose = new THREE.Mesh(new THREE.CylinderGeometry(0.105, 0.065, 0.065, 12), dark);
    rose.position.copy(spoutEnd); rose.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(0.45, 0.55, 0.7).normalize());
    group.add(rose);
    group.position.set(2.7, 3.7, 1.05);
    group.visible = false;
    bouquet.add(group);
    wateringCan = group;

    const waterMaterial = new THREE.MeshStandardMaterial({ color: "#9ce6fa", transparent: true, opacity: 0.9, roughness: 0.2, metalness: 0.06 });
    const dropGeo = new THREE.SphereGeometry(0.037, 7, 6);
    waterDrops = Array.from({ length: 17 }, (_, i) => {
      const drop = new THREE.Mesh(dropGeo, waterMaterial.clone());
      bouquet.add(drop);
      drop.visible = false;
      return { mesh: drop, offset: i / 17 };
    });
  }

  function initScene() {
    if (!window.THREE) {
      message.classList.add("on");
      message.innerHTML = "<div><span style=\"font-size:2.7rem\">🌷</span><strong>O buquê está guardado</strong><p>Não consegui carregar o visualizador 3D. Confira a conexão e atualize a página para tentar de novo.</p></div>";
      return;
    }
    try {
      scene = new THREE.Scene();
      scene.background = null;
      camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
      camera.position.set(2.2, 4.8, zoomDistance);
      camera.lookAt(0, 1.55, 0);
      updateZoom();

      renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: "low-power" });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
      renderer.setSize(stage.clientWidth, stage.clientHeight, false);
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      renderer.outputEncoding = THREE.sRGBEncoding;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 0.72;

      scene.add(new THREE.HemisphereLight("#fffdf9", "#756748", 0.86));
      const key = new THREE.DirectionalLight("#fff6e9", 1.45);
      key.position.set(-3.8, 8.5, 5.6); key.castShadow = true;
      key.shadow.mapSize.set(1024, 1024); scene.add(key);
      const fill = new THREE.DirectionalLight("#e7d3ff", 0.42);
      fill.position.set(5, 4, -4); scene.add(fill);
      const front = new THREE.PointLight("#fff0c7", 0.2, 15);
      front.position.set(1, 3, 5); scene.add(front);

      const ground = new THREE.Mesh(
        new THREE.CircleGeometry(3.3, 48),
        new THREE.MeshBasicMaterial({ color: "#cbbabf", transparent: true, opacity: 0.14, depthWrite: false })
      );
      ground.rotation.x = -Math.PI / 2; ground.position.y = -0.64; ground.scale.set(1, 0.46, 1); scene.add(ground);

      bouquet = new THREE.Group();
      scene.add(bouquet);

      // Folhagens altas e folhas largas lembram o arranjo das fotos.
      for (let i = 0; i < 13; i++) {
        const angle = i * 2.399;
        const y = 1.08 + (i % 4) * 0.13;
        addLeaf(bouquet, Math.cos(angle) * 0.28, y, Math.sin(angle) * 0.26, angle, 1.18 + (i % 3) * 0.18, 0.18 + (i % 2) * 0.035);
      }
      for (let i = 0; i < 5; i++) {
        const angle = i * 1.256;
        lineBetween(bouquet,
          new THREE.Vector3(Math.cos(angle) * 0.14, -0.27, Math.sin(angle) * 0.14),
          new THREE.Vector3(Math.cos(angle) * (0.5 + i % 2 * 0.2), 1.58 + (i % 2) * 0.15, Math.sin(angle) * (0.45 + i % 2 * 0.2)),
          0.025, new THREE.MeshStandardMaterial({ color: "#58863c", roughness: 0.78 }), 6);
      }

      // Papel amarelo em pregas, com uma base cônica por baixo.
      const backing = new THREE.Mesh(
        new THREE.CylinderGeometry(1.42, 0.42, 1.86, 32, 1, true),
        new THREE.MeshStandardMaterial({ color: "#f6d33f", side: THREE.DoubleSide, roughness: 0.78, metalness: 0.015 })
      );
      backing.position.y = 0.43; backing.castShadow = true; bouquet.add(backing);
      const shades = ["#f0bd05", "#ffdc35", "#e8b700", "#ffd329", "#e9b800", "#ffe04b", "#e7b500", "#ffda2d", "#e8b300", "#ffd638", "#edbc08", "#ffe24b"];
      for (let i = 0; i < 12; i++) makeWrapPanel(bouquet, i * Math.PI / 6, shades[i]);
      const band = new THREE.Mesh(
        new THREE.TorusGeometry(0.53, 0.075, 8, 42),
        new THREE.MeshStandardMaterial({ color: "#f4cf33", roughness: 0.42, metalness: 0.05 })
      );
      band.rotation.x = Math.PI / 2; band.position.y = 0.0; bouquet.add(band);
      const bow = new THREE.Group(); bow.position.set(0, -0.02, 0.74); bouquet.add(bow);
      for (let side = -1; side <= 1; side += 2) {
        const loop = new THREE.Mesh(
          new THREE.TorusGeometry(0.22, 0.055, 9, 26, Math.PI * 1.65),
          new THREE.MeshStandardMaterial({ color: side < 0 ? "#ffcf0d" : "#f0b900", roughness: 0.42 })
        );
        loop.rotation.z = side * 0.25; loop.rotation.x = Math.PI * 0.04; loop.position.x = side * 0.22; bow.add(loop);
      }
      const ribbonMaterial = new THREE.MeshStandardMaterial({ color: "#ffd83d", roughness: 0.4 });
      for (let side = -1; side <= 1; side += 2) {
        const tail = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.48, 0.025), ribbonMaterial);
        tail.position.set(side * 0.17, -0.28, 0.015);
        tail.rotation.z = side * -0.12;
        bow.add(tail);
      }
      const knot = new THREE.Mesh(new THREE.SphereGeometry(0.13, 12, 9), new THREE.MeshStandardMaterial({ color: "#dca900", roughness: 0.4 }));
      bow.add(knot);

      addFerreroBox(bouquet);
      addBabyBreath(bouquet);

      // Buquê reproduz os lírios grandes e brancos do presente das fotos.
      const blooms = [
        [-1.03, 2.57, -0.22, 0.78, -0.45, 0.28],
        [0.06, 2.78, -0.38, 0.85, 0.15, 0.35],
        [1.05, 2.55, -0.24, 0.78, 0.45, 0.25],
        [-0.3, 2.28, 0.74, 1.0, 0.08, 0.9],
        [0.78, 2.25, 0.58, 0.82, -0.3, 0.78]
      ];
      blooms.forEach(([x, y, z, size, angle, tilt], index) => {
        const stemEnd = new THREE.Vector3(x * 0.48, y - 0.12, z * 0.4);
        const stemStart = new THREE.Vector3(x * 0.16, 0.25 + (index % 2) * 0.12, z * 0.15);
        lineBetween(bouquet, stemStart, stemEnd, 0.027, new THREE.MeshStandardMaterial({ color: "#638d3e", roughness: 0.72 }), 6);
        addLily(bouquet, x, y, z, size, angle, tilt);
      });

      // Cartão amarelo e branco saindo entre as flores.
      const card = new THREE.Group();
      card.position.set(0.83, 1.88, -0.18); card.rotation.z = -0.12; card.rotation.y = -0.2;
      bouquet.add(card);
      const cardPaper = new THREE.Mesh(
        new THREE.BoxGeometry(0.68, 0.82, 0.045),
        new THREE.MeshStandardMaterial({ color: "#fffdf5", roughness: 0.9 })
      );
      cardPaper.castShadow = true; card.add(cardPaper);
      const cardFront = new THREE.Mesh(
        new THREE.PlaneGeometry(0.53, 0.67),
        new THREE.MeshStandardMaterial({ color: "#fff9e9", roughness: 0.95 })
      );
      cardFront.position.z = 0.025; card.add(cardFront);
      const monogram = new THREE.Mesh(
        new THREE.SphereGeometry(0.105, 20, 16),
        new THREE.MeshStandardMaterial({ color: "#bd8c35", roughness: 0.38, metalness: 0.2 })
      );
      monogram.position.set(0, 0.08, 0.055); monogram.scale.set(1, 0.72, 0.2); card.add(monogram);

      makeWateringCan();
      resize();
      animate();
    } catch (error) {
      console.error("Não foi possível montar o buquê 3D:", error);
      message.classList.add("on");
      message.innerHTML = "<div><span style=\"font-size:2.7rem\">🌷</span><strong>O buquê está guardado</strong><p>Este navegador não conseguiu abrir o modelo 3D. Tente atualizar a página ou abrir em outro navegador.</p></div>";
    }
  }

  function resize() {
    if (!renderer || !camera) return;
    const width = Math.max(1, stage.clientWidth);
    const height = Math.max(1, stage.clientHeight);
    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
  }
  window.addEventListener("resize", resize);

  function spawnScent() {
    const symbols = ["🌸", "💜", "✨", "🌼", "♡"];
    for (let i = 0; i < 10; i++) {
      const el = document.createElement("span");
      el.className = "scent";
      el.textContent = symbols[i % symbols.length];
      el.style.left = (22 + rand() * 56) + "%";
      el.style.top = (37 + rand() * 30) + "%";
      el.style.setProperty("--drift", ((rand() - 0.5) * 70) + "px");
      el.style.animationDelay = (rand() * 0.6) + "s";
      stage.appendChild(el);
      setTimeout(() => el.remove(), 3000);
    }
    showToast("🌸 Hmmm... cheirinho de lírio fresquinho!");
  }

  smellButton.addEventListener("click", () => {
    if (selectedId !== FIRST_GIFT.id) {
      selectGift(FIRST_GIFT.id);
      showToast("O buquê está aqui. Agora pode sentir o perfume dele! 🌸");
    }
    smellStart = performance.now();
    spawnScent();
  });

  waterButton.addEventListener("click", () => {
    if (selectedId !== FIRST_GIFT.id) {
      selectGift(FIRST_GIFT.id);
      showToast("Vamos cuidar do buquê de lírios. 💐");
    }
    if (waterStart >= 0) return;
    waterStart = performance.now();
    waterButton.disabled = true;
    waterButton.textContent = "💧 Regando...";
    showToast("💧 Um pouquinho de água para manter as flores lindas!");
  });

  function removePointers() {
    if (pointers.size < 2) previousPointer = null;
  }
  canvas.addEventListener("pointerdown", (event) => {
    event.preventDefault();
    pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
    try { canvas.setPointerCapture(event.pointerId); } catch (error) { /* Pointer capture may be unavailable in older browsers. */ }
    if (pointers.size === 1) {
      dragging = true;
      previousPointer = { x: event.clientX, y: event.clientY };
    }
  });
  canvas.addEventListener("pointermove", (event) => {
    if (!pointers.has(event.pointerId)) return;
    const old = pointers.get(event.pointerId);
    pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (pointers.size >= 2) {
      const pts = [...pointers.values()];
      const distance = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      if (previousPointer && previousPointer.distance) {
        zoomDistance = THREE.MathUtils.clamp(zoomDistance + (previousPointer.distance - distance) * 0.018, 6.5, 13);
        updateZoom();
      }
      previousPointer = { distance };
      return;
    }
    if (!dragging || !bouquet) return;
    const dx = event.clientX - old.x, dy = event.clientY - old.y;
    bouquet.rotation.y += dx * 0.009;
    bouquet.rotation.x = THREE.MathUtils.clamp(bouquet.rotation.x + dy * 0.004, -0.36, 0.34);
    lastDrag = performance.now();
    autoRotate = false;
  });
  ["pointerup", "pointercancel", "lostpointercapture"].forEach((name) => {
    canvas.addEventListener(name, (event) => {
      pointers.delete(event.pointerId);
      dragging = pointers.size === 1;
      removePointers();
      if (!pointers.size) setTimeout(() => { autoRotate = true; }, 2300);
    });
  });
  stage.addEventListener("wheel", (event) => {
    if (!renderer) return;
    event.preventDefault();
    zoomDistance = THREE.MathUtils.clamp(zoomDistance + Math.sign(event.deltaY) * 0.4, 6.5, 13);
    updateZoom();
  }, { passive: false });

  function updateZoom() {
    if (!camera) return;
    const direction = new THREE.Vector3(2.2, 4.8, 10).normalize();
    camera.position.copy(direction.multiplyScalar(zoomDistance));
    camera.lookAt(0, 1.55, 0);
  }

  function updateWater(time) {
    if (waterStart < 0 || !wateringCan || !bouquet) return;
    const elapsed = (time - waterStart) / 1000;
    const duration = 5.2;
    const progress = Math.min(1, elapsed / duration);
    wateringCan.visible = progress < 0.96;
    wateringCan.position.set(
      2.5 - Math.sin(progress * Math.PI) * 0.75,
      3.95 - Math.sin(progress * Math.PI) * 0.56,
      1.05 + Math.sin(progress * Math.PI) * 0.32
    );
    wateringCan.rotation.z = -Math.sin(progress * Math.PI) * 0.72;
    waterDrops.forEach(({ mesh, offset }) => {
      const stream = (progress * 1.6 + offset) % 1;
      const active = progress > 0.16 && progress < 0.9;
      mesh.visible = active && (stream > 0.15 || offset < progress);
      const x = 1.42 - stream * 0.45 + Math.sin((stream + offset) * 12) * 0.07;
      const y = 3.14 - stream * 2.15;
      const z = 1.35 + stream * 0.42 + Math.cos((stream + offset) * 9) * 0.05;
      mesh.position.set(x, y, z);
      mesh.scale.set(0.8, 1.5 + stream * 0.5, 0.8);
      mesh.material.opacity = 0.8 * (1 - stream * 0.3);
    });
    if (progress >= 1) {
      wateringCan.visible = false;
      waterDrops.forEach(({ mesh }) => { mesh.visible = false; });
      waterStart = -1;
      waterButton.disabled = false;
      waterButton.textContent = "💧 Regar";
      showToast("🌿 Prontinho! Os lírios estão hidratados.");
    }
  }

  function animate(time = performance.now()) {
    if (!renderer || !scene) return;
    const delta = Math.min(0.05, (time - lastFrame) / 1000);
    lastFrame = time;
    if (bouquet && autoRotate && !dragging && time - lastDrag > 2400) bouquet.rotation.y += delta * 0.13;
    if (smellStart >= 0 && petals.length) {
      const elapsed = (time - smellStart) / 1000;
      const pulse = 1 + Math.max(0, Math.sin(elapsed * Math.PI * 3)) * Math.max(0, 1 - elapsed / 2) * 0.055;
      petals.forEach((petal) => petal.scale.setScalar(pulse));
      if (elapsed > 2) { petals.forEach((petal) => petal.scale.setScalar(1)); smellStart = -1; }
    }
    updateWater(time);
    renderer.render(scene, camera);
    requestAnimationFrame(animate);
  }

  initScene();
})();
